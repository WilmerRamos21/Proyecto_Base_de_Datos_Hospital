--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg120+1)
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hospital; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA respaldo_hospital;


ALTER SCHEMA respaldo_hospital OWNER TO postgres;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA hospital;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA hospital;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: actualizar_estado_tratamientos(); Type: PROCEDURE; Schema: hospital; Owner: postgres
--

CREATE PROCEDURE hospital.actualizar_estado_tratamientos()
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE tratamientos
    SET estado = 'Finalizado'
    WHERE fecha_fin < CURRENT_DATE
      AND estado != 'Finalizado';

    RAISE NOTICE 'Se actualizaron los tratamientos vencidos a Finalizado.';
END;
$$;


ALTER PROCEDURE hospital.actualizar_estado_tratamientos() OWNER TO postgres;

--
-- Name: calcular_edad(integer); Type: FUNCTION; Schema: hospital; Owner: postgres
--

CREATE FUNCTION hospital.calcular_edad(p_id_paciente integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_fecha_nacimiento DATE;
    v_edad INT;
BEGIN
    SELECT fecha_nacimiento INTO v_fecha_nacimiento
    FROM pacientes
    WHERE id_paciente = p_id_paciente;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Paciente no encontrado.';
    END IF;

    v_edad := DATE_PART('year', AGE(CURRENT_DATE, v_fecha_nacimiento));

    RETURN v_edad;
END;
$$;


ALTER FUNCTION hospital.calcular_edad(p_id_paciente integer) OWNER TO postgres;

--
-- Name: descontar_stock_medicamento(); Type: FUNCTION; Schema: hospital; Owner: postgres
--

CREATE FUNCTION hospital.descontar_stock_medicamento() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE medicamentos
    SET stock_actual = stock_actual - 1
    WHERE id_medicamento = NEW.id_medicamento;

    RETURN NEW;
END;
$$;


ALTER FUNCTION hospital.descontar_stock_medicamento() OWNER TO postgres;

--
-- Name: duracion_tratamiento(integer); Type: FUNCTION; Schema: hospital; Owner: postgres
--

CREATE FUNCTION hospital.duracion_tratamiento(p_id_tratamiento integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_inicio DATE;
    v_fin DATE;
BEGIN
    SELECT fecha_inicio, fecha_fin INTO v_inicio, v_fin
    FROM tratamientos
    WHERE id_tratamiento = p_id_tratamiento;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Tratamiento no encontrado.';
    END IF;

    RETURN v_fin - v_inicio;
END;
$$;


ALTER FUNCTION hospital.duracion_tratamiento(p_id_tratamiento integer) OWNER TO postgres;

--
-- Name: eliminar_paciente_seguro(integer); Type: PROCEDURE; Schema: hospital; Owner: postgres
--

CREATE PROCEDURE hospital.eliminar_paciente_seguro(IN p_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Verificar si el paciente tiene citas médicas
    IF EXISTS (
        SELECT 1 FROM citas_medicas WHERE id_paciente = p_id
    ) THEN
        RAISE EXCEPTION 'No se puede eliminar el paciente: tiene citas registradas.';
    END IF;

    DELETE FROM pacientes WHERE id_paciente = p_id;
    RAISE NOTICE 'Paciente eliminado exitosamente.';
END;
$$;


ALTER PROCEDURE hospital.eliminar_paciente_seguro(IN p_id integer) OWNER TO postgres;

--
-- Name: estado_tratamiento_paciente(integer); Type: FUNCTION; Schema: hospital; Owner: postgres
--

CREATE FUNCTION hospital.estado_tratamiento_paciente(p_id_paciente integer) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_estado VARCHAR;
BEGIN
    SELECT estado INTO v_estado
    FROM tratamientos
    WHERE id_paciente = p_id_paciente AND estado = 'Activo'
    LIMIT 1;

    IF FOUND THEN
        RETURN 'Activo';
    ELSE
        RETURN 'Sin tratamiento activo';
    END IF;
END;
$$;


ALTER FUNCTION hospital.estado_tratamiento_paciente(p_id_paciente integer) OWNER TO postgres;

--
-- Name: fn_log_accion(); Type: FUNCTION; Schema: hospital; Owner: postgres
--

CREATE FUNCTION hospital.fn_log_accion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_usuario TEXT := current_user;
    v_rol TEXT := session_user;
    v_ip TEXT := inet_client_addr()::TEXT;
    v_terminal TEXT := 'localhost';
    v_accion TEXT;
    v_hash TEXT := NULL;
BEGIN
    IF TG_OP = 'INSERT' THEN
        v_accion := 'INSERT';

    ELSIF TG_OP = 'UPDATE' THEN
        v_accion := 'UPDATE';
        v_hash := encode(digest(ROW(OLD.*)::TEXT, 'sha256'), 'hex');

    ELSIF TG_OP = 'DELETE' THEN
        v_accion := 'DELETE';
        v_hash := encode(digest(ROW(OLD.*)::TEXT, 'sha256'), 'hex');
    END IF;

    -- Insertar log
    INSERT INTO log_acciones (
        usuario, rol_actual, ip_origen, terminal,
        accion, tabla_afectada, id_afectado, transaccion, hash_anterior
    )
    VALUES (
        v_usuario, v_rol, v_ip, v_terminal,
        v_accion, TG_TABLE_NAME, NULL, NULL, v_hash
    );

    RETURN NULL;
END;
$$;


ALTER FUNCTION hospital.fn_log_accion() OWNER TO postgres;

--
-- Name: generar_factura_automatica(integer); Type: PROCEDURE; Schema: hospital; Owner: postgres
--

CREATE PROCEDURE hospital.generar_factura_automatica(IN p_id_cita integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_tipo_consulta VARCHAR(20);
    v_total NUMERIC(10,2);
    v_existente INT;
BEGIN
    -- Iniciar transacción
    BEGIN
        -- Validar que la cita exista
        IF NOT EXISTS (SELECT 1 FROM citas_medicas WHERE id_cita = p_id_cita) THEN
            RAISE EXCEPTION 'La cita no existe.';
        END IF;

        -- Validar si ya tiene factura
        SELECT COUNT(*) INTO v_existente FROM facturas WHERE id_cita = p_id_cita;
        IF v_existente > 0 THEN
            RAISE EXCEPTION 'La cita ya tiene factura generada.';
        END IF;

        -- Obtener tipo de consulta y costo
        SELECT tipo_consulta INTO v_tipo_consulta FROM citas_medicas WHERE id_cita = p_id_cita;
        SELECT costo INTO v_total FROM tarifas WHERE tipo_consulta = v_tipo_consulta;

        -- Insertar factura
        INSERT INTO facturas (id_cita, fecha_emision, total, tipo_consulta)
        VALUES (p_id_cita, CURRENT_DATE, v_total, v_tipo_consulta);

        RAISE NOTICE 'Factura generada correctamente para la cita % con costo %', p_id_cita, v_total;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error en la generación automática de factura: %', SQLERRM;
    END;
END;
$$;


ALTER PROCEDURE hospital.generar_factura_automatica(IN p_id_cita integer) OWNER TO postgres;

--
-- Name: insertar_cita(integer, integer, date, time without time zone, character varying, character varying); Type: PROCEDURE; Schema: hospital; Owner: postgres
--

CREATE PROCEDURE hospital.insertar_cita(IN p_id_paciente integer, IN p_id_medico integer, IN p_fecha date, IN p_hora time without time zone, IN p_estado character varying, IN p_tipo_consulta character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN 
	-- Validar si paciente existe
	IF NOT EXISTS (
		SELECT 1 FROM pacientes
		WHERE id_paciente = p_id_paciente
		)THEN 
		RAISE EXCEPTION 'Paciente no existe.';
	END IF;

	-- Validar si doctor existe 
	IF NOT EXISTS (
	SELECT 1 FROM medicos
	WHERE id_medico = p_id_medico
	)THEN 
	RAISE EXCEPTION 'Medico no existe.';
	END IF;
	
	-- Insertar cita medica
	INSERT INTO citas_medicas(id_paciente, id_medico, fecha, hora, estado, tipo_consulta)
	VALUES (p_id_paciente, p_id_medico, p_fecha, p_hora, p_estado, p_tipo_consulta);
	
END;
$$;


ALTER PROCEDURE hospital.insertar_cita(IN p_id_paciente integer, IN p_id_medico integer, IN p_fecha date, IN p_hora time without time zone, IN p_estado character varying, IN p_tipo_consulta character varying) OWNER TO postgres;

--
-- Name: log_cambios_usuarios(); Type: FUNCTION; Schema: hospital; Owner: postgres
--

CREATE FUNCTION hospital.log_cambios_usuarios() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO log_usuarios(id_usuario, accion, nombre_usuario)
        VALUES (NEW.id_usuario, 'INSERT', NEW.nombre_usuario);
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO log_usuarios(id_usuario, accion, nombre_usuario)
        VALUES (NEW.id_usuario, 'UPDATE', NEW.nombre_usuario);
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO log_usuarios(id_usuario, accion, nombre_usuario)
        VALUES (OLD.id_usuario, 'DELETE', OLD.nombre_usuario);
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION hospital.log_cambios_usuarios() OWNER TO postgres;

--
-- Name: notificar_cita_paciente(); Type: FUNCTION; Schema: hospital; Owner: postgres
--

CREATE FUNCTION hospital.notificar_cita_paciente() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_nombre TEXT;
BEGIN
    IF NEW.estado = 'Pendiente' THEN
        SELECT CONCAT(nombres, ' ', apellidos) INTO v_nombre
        FROM pacientes WHERE id_paciente = NEW.id_paciente;

        INSERT INTO notificaciones(id_cita, mensaje)
        VALUES (
            NEW.id_cita,
            'Se ha agendado una nueva cita para el paciente ' || v_nombre
        );
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION hospital.notificar_cita_paciente() OWNER TO postgres;

--
-- Name: reporte_citas_medicas(integer, date, date); Type: PROCEDURE; Schema: hospital; Owner: postgres
--

CREATE PROCEDURE hospital.reporte_citas_medicas(IN p_id_medico integer, IN p_fecha_inicio date, IN p_fecha_fin date)
    LANGUAGE plpgsql
    AS $$
DECLARE
	rec RECORD;
BEGIN
	RAISE NOTICE 'Citas del medico % entre % y %: ', p_id_medico, p_fecha_inicio, p_fecha_fin;

	FOR rec IN
		SELECT *
		FROM citas_medicas
		WHERE id_medico = p_id_medico
			AND fecha BETWEEN p_fecha_inicio AND p_fecha_fin
	LOOP
		RAISE NOTICE 'Cita: %, Paciente: %, Fecha: %, Hora: %',
			rec.id_cita, rec.id_paciente, rec.fecha, rec.hora;
	END LOOP;
END;
$$;


ALTER PROCEDURE hospital.reporte_citas_medicas(IN p_id_medico integer, IN p_fecha_inicio date, IN p_fecha_fin date) OWNER TO postgres;

--
-- Name: total_pacientes_rango(date, date); Type: FUNCTION; Schema: hospital; Owner: postgres
--

CREATE FUNCTION hospital.total_pacientes_rango(fecha1 date, fecha2 date) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
  total INT;
BEGIN
  SELECT COUNT(*) INTO total
  FROM pacientes
  WHERE fecha_creacion BETWEEN fecha1 AND fecha2;
  RETURN total;
END;
$$;


ALTER FUNCTION hospital.total_pacientes_rango(fecha1 date, fecha2 date) OWNER TO postgres;

--
-- Name: validar_cita(integer, date); Type: FUNCTION; Schema: hospital; Owner: postgres
--

CREATE FUNCTION hospital.validar_cita(p_medico integer, p_fecha date) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
  existe INT;
BEGIN
  SELECT COUNT(*) INTO existe
  FROM citas
  WHERE id_medico = p_medico AND fecha = p_fecha;

  IF existe > 0 THEN
    RAISE EXCEPTION 'El médico ya tiene una cita ese día.';
  END IF;

  RETURN TRUE;
END;
$$;


ALTER FUNCTION hospital.validar_cita(p_medico integer, p_fecha date) OWNER TO postgres;

--
-- Name: validar_edad(date); Type: FUNCTION; Schema: hospital; Owner: postgres
--

CREATE FUNCTION hospital.validar_edad(p_fecha_nacimiento date) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF age(p_fecha_nacimiento) < INTERVAL '18 years' THEN
    RAISE EXCEPTION 'Solo se permiten mayores de 18 años.';
  END IF;
  RETURN TRUE;
END;
$$;


ALTER FUNCTION hospital.validar_edad(p_fecha_nacimiento date) OWNER TO postgres;

--
-- Name: validar_email(text); Type: FUNCTION; Schema: hospital; Owner: postgres
--

CREATE FUNCTION hospital.validar_email(p_email text) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
BEGIN
  IF pemail ~* '^[A-Za-z0-9.%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,}$' THEN
    RETURN TRUE;
  ELSE
    RAISE EXCEPTION 'Email inválido.';
  END IF;
END;
$_$;


ALTER FUNCTION hospital.validar_email(p_email text) OWNER TO postgres;

--
-- Name: validar_usuario(text); Type: FUNCTION; Schema: hospital; Owner: postgres
--

CREATE FUNCTION hospital.validar_usuario(p_usuario text) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
BEGIN
  IF p_usuario ~ '^[a-zA-Z0-9]+$' THEN
    RETURN TRUE;
  ELSE
    RAISE EXCEPTION 'Usuario contiene caracteres inválidos.';
  END IF;
END;
$_$;


ALTER FUNCTION hospital.validar_usuario(p_usuario text) OWNER TO postgres;

--
-- Name: validaremail(text); Type: FUNCTION; Schema: hospital; Owner: postgres
--

CREATE FUNCTION hospital.validaremail(correo text) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
BEGIN
    IF correo ~* '^[A-Za-z0-9.%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,}$' THEN
        RETURN TRUE;
    ELSE
        RAISE EXCEPTION 'Correo inválido';
    END IF;
END;
$_$;


ALTER FUNCTION hospital.validaremail(correo text) OWNER TO postgres;

--
-- Name: validaremail(character varying); Type: FUNCTION; Schema: hospital; Owner: postgres
--

CREATE FUNCTION hospital.validaremail(correo character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
BEGIN
    IF correo ~* '^[A-Za-z0-9.%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,}$' THEN
        RETURN TRUE;
    ELSE
        RAISE EXCEPTION 'Correo inválido';
    END IF;
END;
$_$;


ALTER FUNCTION hospital.validaremail(correo character varying) OWNER TO postgres;

--
-- Name: fn_log_accion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_log_accion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_usuario TEXT := current_user;
    v_rol TEXT := session_user;
    v_ip TEXT := inet_client_addr()::TEXT;
    v_terminal TEXT := 'localhost';
    v_accion TEXT;
    v_hash TEXT := NULL;
BEGIN
    IF TG_OP = 'INSERT' THEN
        v_accion := 'INSERT';

    ELSIF TG_OP = 'UPDATE' THEN
        v_accion := 'UPDATE';
        v_hash := encode(digest(ROW(OLD.*)::TEXT, 'sha256'), 'hex');

    ELSIF TG_OP = 'DELETE' THEN
        v_accion := 'DELETE';
        v_hash := encode(digest(ROW(OLD.*)::TEXT, 'sha256'), 'hex');
    END IF;

    -- Insertar log
    INSERT INTO log_acciones (
        usuario, rol_actual, ip_origen, terminal,
        accion, tabla_afectada, id_afectado, transaccion, hash_anterior
    )
    VALUES (
        v_usuario, v_rol, v_ip, v_terminal,
        v_accion, TG_TABLE_NAME, NULL, NULL, v_hash
    );

    RETURN NULL;
END;
$$;


ALTER FUNCTION public.fn_log_accion() OWNER TO postgres;

--
-- Name: validaremail(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.validaremail(correo character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
BEGIN
    IF correo ~* '^[A-Za-z0-9.%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,}$' THEN
        RETURN TRUE;
    ELSE
        RAISE EXCEPTION 'Correo inválido';
    END IF;
END;
$_$;


ALTER FUNCTION public.validaremail(correo character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: citas_medicas; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.citas_medicas (
    id_cita integer NOT NULL,
    id_paciente integer NOT NULL,
    id_medico integer NOT NULL,
    fecha date NOT NULL,
    hora time without time zone NOT NULL,
    estado character varying(20) NOT NULL,
    tipo_consulta character varying(20) NOT NULL,
    CONSTRAINT citas_medicas_estado_check CHECK (((estado)::text = ANY ((ARRAY['Pendiente'::character varying, 'Atendida'::character varying, 'Cancelada'::character varying])::text[]))),
    CONSTRAINT citas_medicas_tipo_consulta_check CHECK (((tipo_consulta)::text = ANY ((ARRAY['General'::character varying, 'Especialista'::character varying, 'Emergencia'::character varying])::text[])))
);


ALTER TABLE hospital.citas_medicas OWNER TO postgres;

--
-- Name: citas_medicas_id_cita_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.citas_medicas_id_cita_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.citas_medicas_id_cita_seq OWNER TO postgres;

--
-- Name: citas_medicas_id_cita_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.citas_medicas_id_cita_seq OWNED BY hospital.citas_medicas.id_cita;


--
-- Name: detalle_receta; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.detalle_receta (
    id_detalle integer NOT NULL,
    id_receta integer NOT NULL,
    id_medicamento integer NOT NULL,
    dosis character varying(100) NOT NULL,
    frecuencia character varying(100) NOT NULL,
    duracion_dias integer NOT NULL,
    CONSTRAINT detalle_receta_duracion_dias_check CHECK ((duracion_dias > 0))
);


ALTER TABLE hospital.detalle_receta OWNER TO postgres;

--
-- Name: detalle_receta_id_detalle_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.detalle_receta_id_detalle_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.detalle_receta_id_detalle_seq OWNER TO postgres;

--
-- Name: detalle_receta_id_detalle_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.detalle_receta_id_detalle_seq OWNED BY hospital.detalle_receta.id_detalle;


--
-- Name: especialidades; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.especialidades (
    id_especialidad integer NOT NULL,
    nombre_especialidad character varying(100) NOT NULL
);


ALTER TABLE hospital.especialidades OWNER TO postgres;

--
-- Name: especialidades_id_especialidad_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.especialidades_id_especialidad_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.especialidades_id_especialidad_seq OWNER TO postgres;

--
-- Name: especialidades_id_especialidad_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.especialidades_id_especialidad_seq OWNED BY hospital.especialidades.id_especialidad;


--
-- Name: facturas; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.facturas (
    id_factura integer NOT NULL,
    id_cita integer NOT NULL,
    fecha_emision date NOT NULL,
    total numeric(10,2) NOT NULL,
    tipo_consulta character varying(20) NOT NULL,
    CONSTRAINT facturas_tipo_consulta_check CHECK (((tipo_consulta)::text = ANY ((ARRAY['General'::character varying, 'Especialista'::character varying, 'Emergencia'::character varying])::text[])))
);


ALTER TABLE hospital.facturas OWNER TO postgres;

--
-- Name: facturas_id_factura_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.facturas_id_factura_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.facturas_id_factura_seq OWNER TO postgres;

--
-- Name: facturas_id_factura_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.facturas_id_factura_seq OWNED BY hospital.facturas.id_factura;


--
-- Name: log_acciones; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.log_acciones (
    id integer NOT NULL,
    usuario text,
    rol_actual text,
    ip_origen text,
    terminal text,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    accion text,
    tabla_afectada text,
    id_afectado integer,
    transaccion text,
    hash_anterior text
);


ALTER TABLE hospital.log_acciones OWNER TO postgres;

--
-- Name: log_acciones_id_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.log_acciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.log_acciones_id_seq OWNER TO postgres;

--
-- Name: log_acciones_id_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.log_acciones_id_seq OWNED BY hospital.log_acciones.id;


--
-- Name: log_intentos; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.log_intentos (
    id integer NOT NULL,
    usuario text,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    ip_origen text,
    mensaje text
);


ALTER TABLE hospital.log_intentos OWNER TO postgres;

--
-- Name: log_intentos_id_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.log_intentos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.log_intentos_id_seq OWNER TO postgres;

--
-- Name: log_intentos_id_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.log_intentos_id_seq OWNED BY hospital.log_intentos.id;


--
-- Name: log_usuarios; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE respaldo_hospital.log_usuarios (
    id_log integer NOT NULL,
    id_usuario integer,
    accion character varying(10),
    nombre_usuario character varying(50),
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);

SELECT * FROM log_acciones;

ALTER TABLE hospital.log_usuarios OWNER TO postgres;

--
-- Name: log_usuarios_id_log_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.log_usuarios_id_log_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.log_usuarios_id_log_seq OWNER TO postgres;

--
-- Name: log_usuarios_id_log_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.log_usuarios_id_log_seq OWNED BY hospital.log_usuarios.id_log;


--
-- Name: medicamentos; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.medicamentos (
    id_medicamento integer NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion text NOT NULL,
    stock_actual integer NOT NULL,
    CONSTRAINT medicamentos_stock_actual_check CHECK ((stock_actual >= 0))
);


ALTER TABLE hospital.medicamentos OWNER TO postgres;

--
-- Name: medicamentos_id_medicamento_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.medicamentos_id_medicamento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.medicamentos_id_medicamento_seq OWNER TO postgres;

--
-- Name: medicamentos_id_medicamento_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.medicamentos_id_medicamento_seq OWNED BY hospital.medicamentos.id_medicamento;


--
-- Name: medicos; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.medicos (
    id_medico integer NOT NULL,
    nombres character varying(100) NOT NULL,
    apellidos character varying(100) NOT NULL,
    especialidad_id integer NOT NULL,
    telefono character varying(20) NOT NULL,
    email character varying(250) NOT NULL
);


ALTER TABLE hospital.medicos OWNER TO postgres;

--
-- Name: medicos_id_medico_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.medicos_id_medico_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.medicos_id_medico_seq OWNER TO postgres;

--
-- Name: medicos_id_medico_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.medicos_id_medico_seq OWNED BY hospital.medicos.id_medico;


--
-- Name: notificaciones; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.notificaciones (
    id_notificacion integer NOT NULL,
    id_cita integer,
    mensaje text,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE hospital.notificaciones OWNER TO postgres;

--
-- Name: notificaciones_id_notificacion_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.notificaciones_id_notificacion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.notificaciones_id_notificacion_seq OWNER TO postgres;

--
-- Name: notificaciones_id_notificacion_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.notificaciones_id_notificacion_seq OWNED BY hospital.notificaciones.id_notificacion;


--
-- Name: pacientes; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.pacientes (
    id_paciente integer NOT NULL,
    nombres character varying(100) NOT NULL,
    apellidos character varying(100) NOT NULL,
    fecha_nacimiento date NOT NULL,
    genero character(1) NOT NULL,
    direccion text NOT NULL,
    telefono character varying(20) NOT NULL,
    email character varying(250) NOT NULL,
    contacto_emergencia_nombre character varying(100) NOT NULL,
    contacto_emergencia_telefono character varying(20) NOT NULL,
    historia_clinica text NOT NULL,
    fecha_creacion timestamp without time zone DEFAULT now(),
    CONSTRAINT pacientes_genero_check CHECK ((genero = ANY (ARRAY['M'::bpchar, 'F'::bpchar])))
);


ALTER TABLE hospital.pacientes OWNER TO postgres;

--
-- Name: pacientes_id_paciente_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.pacientes_id_paciente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.pacientes_id_paciente_seq OWNER TO postgres;

--
-- Name: pacientes_id_paciente_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.pacientes_id_paciente_seq OWNED BY hospital.pacientes.id_paciente;


--
-- Name: recetas; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.recetas (
    id_receta integer NOT NULL,
    id_cita integer NOT NULL,
    fecha date NOT NULL,
    observaciones text NOT NULL,
    entregada boolean DEFAULT false NOT NULL
);


ALTER TABLE hospital.recetas OWNER TO postgres;

--
-- Name: recetas_id_receta_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.recetas_id_receta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.recetas_id_receta_seq OWNER TO postgres;

--
-- Name: recetas_id_receta_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.recetas_id_receta_seq OWNED BY hospital.recetas.id_receta;


--
-- Name: roles; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.roles (
    id_rol integer NOT NULL,
    nombre_rol character varying(20) NOT NULL,
    CONSTRAINT roles_nombre_rol_check CHECK (((nombre_rol)::text = ANY ((ARRAY['Recepcionista'::character varying, 'Doctor'::character varying, 'Farmacia'::character varying, 'Auditor'::character varying])::text[])))
);


ALTER TABLE hospital.roles OWNER TO postgres;

--
-- Name: roles_id_rol_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.roles_id_rol_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.roles_id_rol_seq OWNER TO postgres;

--
-- Name: roles_id_rol_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.roles_id_rol_seq OWNED BY hospital.roles.id_rol;


--
-- Name: tarifas; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.tarifas (
    tipo_consulta character varying(20) NOT NULL,
    costo numeric(10,2) NOT NULL,
    CONSTRAINT tarifas_costo_check CHECK ((costo >= (0)::numeric)),
    CONSTRAINT tarifas_tipo_consulta_check CHECK (((tipo_consulta)::text = ANY ((ARRAY['General'::character varying, 'Especialista'::character varying, 'Emergencia'::character varying])::text[])))
);


ALTER TABLE hospital.tarifas OWNER TO postgres;

--
-- Name: tratamientos; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.tratamientos (
    id_tratamiento integer NOT NULL,
    id_paciente integer NOT NULL,
    descripcion text NOT NULL,
    fecha_inicio date NOT NULL,
    fecha_fin date NOT NULL,
    estado character varying(20) NOT NULL,
    CONSTRAINT tratamientos_estado_check CHECK (((estado)::text = ANY ((ARRAY['Activo'::character varying, 'Finalizado'::character varying, 'Suspendido'::character varying])::text[])))
);


ALTER TABLE hospital.tratamientos OWNER TO postgres;

--
-- Name: tratamientos_id_tratamiento_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.tratamientos_id_tratamiento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.tratamientos_id_tratamiento_seq OWNER TO postgres;

--
-- Name: tratamientos_id_tratamiento_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.tratamientos_id_tratamiento_seq OWNED BY hospital.tratamientos.id_tratamiento;


--
-- Name: usuarios; Type: TABLE; Schema: hospital; Owner: postgres
--

CREATE TABLE hospital.usuarios (
    id_usuario integer NOT NULL,
    nombre_usuario character varying(50) NOT NULL,
    clave character varying(250) NOT NULL,
    rol_id integer NOT NULL
);


ALTER TABLE hospital.usuarios OWNER TO postgres;

--
-- Name: usuarios_id_usuario_seq; Type: SEQUENCE; Schema: hospital; Owner: postgres
--

CREATE SEQUENCE hospital.usuarios_id_usuario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hospital.usuarios_id_usuario_seq OWNER TO postgres;

--
-- Name: usuarios_id_usuario_seq; Type: SEQUENCE OWNED BY; Schema: hospital; Owner: postgres
--

ALTER SEQUENCE hospital.usuarios_id_usuario_seq OWNED BY hospital.usuarios.id_usuario;


--
-- Name: vista_resumen_citas; Type: VIEW; Schema: hospital; Owner: postgres
--

CREATE VIEW hospital.vista_resumen_citas AS
 SELECT m.nombres AS medico,
    count(*) AS total_citas
   FROM (hospital.citas_medicas c
     JOIN hospital.medicos m ON ((c.id_medico = m.id_medico)))
  GROUP BY m.nombres;


ALTER VIEW hospital.vista_resumen_citas OWNER TO postgres;

--
-- Name: log_acciones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.log_acciones (
    id integer NOT NULL,
    usuario text,
    rol_actual text,
    ip_origen text,
    terminal text,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    accion text,
    tabla_afectada text,
    id_afectado integer,
    transaccion text,
    hash_anterior text
);


ALTER TABLE public.log_acciones OWNER TO postgres;

--
-- Name: log_acciones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.log_acciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.log_acciones_id_seq OWNER TO postgres;

--
-- Name: log_acciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.log_acciones_id_seq OWNED BY public.log_acciones.id;


--
-- Name: citas_medicas id_cita; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.citas_medicas ALTER COLUMN id_cita SET DEFAULT nextval('hospital.citas_medicas_id_cita_seq'::regclass);


--
-- Name: detalle_receta id_detalle; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.detalle_receta ALTER COLUMN id_detalle SET DEFAULT nextval('hospital.detalle_receta_id_detalle_seq'::regclass);


--
-- Name: especialidades id_especialidad; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.especialidades ALTER COLUMN id_especialidad SET DEFAULT nextval('hospital.especialidades_id_especialidad_seq'::regclass);


--
-- Name: facturas id_factura; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.facturas ALTER COLUMN id_factura SET DEFAULT nextval('hospital.facturas_id_factura_seq'::regclass);


--
-- Name: log_acciones id; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.log_acciones ALTER COLUMN id SET DEFAULT nextval('hospital.log_acciones_id_seq'::regclass);


--
-- Name: log_intentos id; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.log_intentos ALTER COLUMN id SET DEFAULT nextval('hospital.log_intentos_id_seq'::regclass);


--
-- Name: log_usuarios id_log; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.log_usuarios ALTER COLUMN id_log SET DEFAULT nextval('hospital.log_usuarios_id_log_seq'::regclass);


--
-- Name: medicamentos id_medicamento; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.medicamentos ALTER COLUMN id_medicamento SET DEFAULT nextval('hospital.medicamentos_id_medicamento_seq'::regclass);


--
-- Name: medicos id_medico; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.medicos ALTER COLUMN id_medico SET DEFAULT nextval('hospital.medicos_id_medico_seq'::regclass);


--
-- Name: notificaciones id_notificacion; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.notificaciones ALTER COLUMN id_notificacion SET DEFAULT nextval('hospital.notificaciones_id_notificacion_seq'::regclass);


--
-- Name: pacientes id_paciente; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.pacientes ALTER COLUMN id_paciente SET DEFAULT nextval('hospital.pacientes_id_paciente_seq'::regclass);


--
-- Name: recetas id_receta; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.recetas ALTER COLUMN id_receta SET DEFAULT nextval('hospital.recetas_id_receta_seq'::regclass);


--
-- Name: roles id_rol; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.roles ALTER COLUMN id_rol SET DEFAULT nextval('hospital.roles_id_rol_seq'::regclass);


--
-- Name: tratamientos id_tratamiento; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.tratamientos ALTER COLUMN id_tratamiento SET DEFAULT nextval('hospital.tratamientos_id_tratamiento_seq'::regclass);


--
-- Name: usuarios id_usuario; Type: DEFAULT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.usuarios ALTER COLUMN id_usuario SET DEFAULT nextval('hospital.usuarios_id_usuario_seq'::regclass);


--
-- Name: log_acciones id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.log_acciones ALTER COLUMN id SET DEFAULT nextval('public.log_acciones_id_seq'::regclass);


--
-- Data for Name: citas_medicas; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.citas_medicas (id_cita, id_paciente, id_medico, fecha, hora, estado, tipo_consulta) FROM stdin;
1	1	1	2025-07-20	10:00:00	Pendiente	General
2	2	2	2025-07-21	11:30:00	Pendiente	Especialista
3	3	5	2025-07-18	09:00:00	Atendida	General
4	4	3	2025-07-22	13:00:00	Cancelada	Especialista
5	5	4	2025-07-19	15:00:00	Atendida	Emergencia
6	1	1	2025-02-10	11:27:33	Atendida	Emergencia
7	1	2	2025-05-03	12:35:37	Cancelada	General
8	3	4	2025-02-28	11:15:21	Cancelada	Especialista
9	2	2	2025-01-03	13:00:40	Pendiente	Emergencia
10	3	2	2025-04-02	10:32:22	Pendiente	General
11	1	3	2024-12-28	08:05:28	Atendida	Especialista
12	2	2	2024-09-18	11:25:52	Atendida	Especialista
13	3	5	2024-09-07	11:16:32	Cancelada	Emergencia
14	2	3	2024-12-25	10:25:50	Cancelada	Emergencia
15	3	1	2024-11-02	14:13:24	Cancelada	Especialista
16	4	1	2025-04-08	14:24:45	Cancelada	Especialista
17	3	5	2024-10-06	09:18:24	Pendiente	General
18	3	5	2025-03-13	09:32:51	Pendiente	Especialista
19	5	3	2025-07-13	14:03:56	Pendiente	Especialista
20	5	5	2024-08-29	09:12:34	Pendiente	Especialista
21	5	5	2025-06-04	10:26:03	Atendida	Emergencia
22	5	2	2025-05-03	08:57:39	Atendida	Especialista
23	1	4	2025-03-20	09:38:52	Atendida	Emergencia
24	2	1	2025-01-03	14:45:07	Cancelada	Emergencia
25	3	4	2024-08-26	14:36:48	Pendiente	Especialista
26	2	5	2025-04-01	14:47:38	Pendiente	General
27	5	1	2025-07-28	15:16:44	Atendida	Emergencia
28	2	5	2025-06-02	15:02:40	Pendiente	Emergencia
29	5	4	2024-09-14	14:21:52	Atendida	Emergencia
30	1	4	2024-12-19	12:21:25	Pendiente	Especialista
31	2	2	2024-08-16	14:41:22	Pendiente	General
32	2	5	2025-03-12	09:47:13	Pendiente	Especialista
33	2	3	2025-03-08	15:43:10	Cancelada	General
34	1	5	2025-01-21	13:13:07	Pendiente	Especialista
35	1	4	2025-07-13	14:07:33	Cancelada	Especialista
36	2	3	2025-07-17	15:46:03	Cancelada	Especialista
37	4	3	2024-09-08	14:26:41	Pendiente	Especialista
38	3	3	2024-09-26	12:25:36	Pendiente	General
39	4	3	2024-11-11	15:53:58	Pendiente	Especialista
40	2	5	2025-03-20	15:49:09	Atendida	General
41	3	5	2025-07-19	15:09:30	Pendiente	Emergencia
42	4	1	2024-09-25	09:46:28	Atendida	Especialista
43	5	4	2024-11-10	13:23:01	Cancelada	General
44	2	1	2025-06-14	13:18:12	Pendiente	Emergencia
45	1	1	2025-02-07	08:07:00	Cancelada	Emergencia
46	4	2	2024-10-04	10:58:01	Atendida	General
47	3	1	2025-03-22	15:07:37	Cancelada	General
48	5	3	2024-09-03	15:30:53	Pendiente	Especialista
49	3	4	2025-01-28	09:19:07	Atendida	General
50	1	4	2025-06-10	11:43:40	Cancelada	Emergencia
51	2	4	2024-10-11	12:02:46	Pendiente	General
52	2	1	2025-05-04	13:27:12	Pendiente	General
53	1	4	2024-08-27	10:25:39	Cancelada	General
54	2	4	2024-10-29	08:12:20	Pendiente	General
55	2	5	2024-12-28	12:23:52	Atendida	Emergencia
56	5	4	2024-09-23	09:28:13	Cancelada	Emergencia
57	2	5	2024-11-12	11:35:15	Atendida	General
58	1	3	2024-08-23	08:55:47	Cancelada	General
59	3	3	2024-08-25	12:30:23	Atendida	Especialista
60	5	2	2025-06-28	14:57:17	Cancelada	Emergencia
61	2	3	2024-10-07	12:01:18	Atendida	Emergencia
62	3	1	2025-01-13	12:23:13	Cancelada	Emergencia
63	5	3	2025-07-16	15:28:01	Pendiente	General
64	4	3	2025-01-17	11:58:52	Atendida	Emergencia
65	5	3	2025-01-31	15:44:50	Cancelada	Emergencia
66	2	2	2024-11-29	13:44:59	Cancelada	Emergencia
67	5	1	2025-05-01	11:10:22	Pendiente	General
68	5	5	2024-11-11	12:37:52	Atendida	Especialista
69	4	3	2025-03-08	09:22:30	Pendiente	Emergencia
70	4	5	2025-02-17	13:14:46	Pendiente	Emergencia
71	2	2	2024-12-03	14:19:51	Pendiente	General
72	3	4	2025-04-09	10:52:09	Cancelada	Especialista
73	4	3	2025-06-03	12:04:25	Cancelada	Emergencia
74	2	3	2025-03-07	10:19:35	Pendiente	General
75	5	3	2025-03-22	15:53:20	Pendiente	Emergencia
76	1	1	2025-06-07	08:26:30	Pendiente	General
77	1	3	2025-01-16	10:55:25	Pendiente	Especialista
78	4	1	2025-01-06	08:50:28	Pendiente	Emergencia
79	1	4	2025-01-20	15:11:24	Pendiente	General
80	1	1	2025-06-16	12:48:53	Pendiente	General
81	4	1	2025-04-28	10:05:16	Pendiente	General
82	2	3	2025-06-12	11:19:51	Cancelada	Emergencia
83	1	1	2024-12-24	14:20:12	Pendiente	General
84	3	5	2024-11-28	12:07:53	Pendiente	Especialista
85	4	3	2025-07-13	15:50:30	Pendiente	Emergencia
86	3	5	2024-12-08	13:03:38	Atendida	Especialista
87	1	3	2024-12-20	12:28:24	Atendida	Especialista
88	4	1	2024-12-22	10:11:13	Pendiente	General
89	2	3	2025-01-12	10:15:02	Pendiente	Especialista
90	2	4	2025-07-19	13:55:57	Pendiente	Emergencia
91	4	4	2025-06-27	11:57:37	Atendida	General
92	5	2	2025-03-22	12:29:37	Cancelada	Emergencia
93	4	5	2025-01-03	09:52:34	Cancelada	Emergencia
94	2	4	2025-01-01	12:10:53	Pendiente	Especialista
95	3	1	2025-06-23	11:01:30	Cancelada	Especialista
96	1	4	2024-10-14	13:17:12	Pendiente	General
97	2	3	2025-02-23	15:22:01	Cancelada	General
98	1	5	2025-01-01	15:31:51	Pendiente	Emergencia
99	4	2	2025-05-09	09:25:00	Pendiente	Emergencia
100	1	3	2024-12-06	09:30:55	Atendida	General
101	1	5	2025-07-16	10:19:15	Cancelada	General
102	1	1	2024-11-23	14:13:07	Pendiente	Especialista
103	2	4	2025-05-30	15:15:26	Pendiente	Especialista
104	5	3	2025-05-26	13:42:16	Atendida	General
105	2	2	2024-12-07	08:01:35	Cancelada	Emergencia
106	2	1	2025-02-27	09:47:13	Atendida	General
107	2	3	2024-12-20	12:36:20	Atendida	Emergencia
108	2	5	2025-07-19	11:12:04	Pendiente	General
109	3	1	2024-11-25	13:27:37	Pendiente	Emergencia
110	3	4	2024-09-14	10:28:40	Atendida	Emergencia
111	2	2	2025-05-01	10:02:15	Atendida	Emergencia
112	5	5	2025-07-01	13:32:56	Pendiente	Especialista
113	1	4	2025-01-13	14:29:57	Cancelada	Emergencia
114	1	2	2025-04-06	14:00:21	Cancelada	General
115	4	1	2024-12-27	14:02:09	Atendida	Especialista
116	1	1	2025-05-13	08:49:52	Atendida	Emergencia
117	5	1	2025-03-15	09:24:43	Atendida	General
118	5	1	2025-03-07	13:12:59	Pendiente	General
119	1	2	2024-08-02	09:26:51	Cancelada	General
120	1	2	2025-02-21	12:48:07	Pendiente	Especialista
121	1	1	2025-02-10	14:06:01	Pendiente	Especialista
122	4	2	2025-04-22	15:06:09	Cancelada	Emergencia
123	4	3	2024-09-05	12:44:42	Pendiente	General
124	4	5	2025-05-05	14:11:52	Pendiente	Emergencia
125	1	3	2024-10-24	13:05:55	Pendiente	Especialista
126	4	1	2025-02-07	08:25:25	Atendida	General
127	5	1	2024-12-28	12:01:30	Atendida	Especialista
128	5	4	2025-05-05	13:35:57	Cancelada	Especialista
129	5	5	2024-11-24	14:28:04	Cancelada	General
130	3	3	2024-12-15	11:17:30	Pendiente	Emergencia
131	2	2	2024-08-03	09:49:39	Atendida	General
132	4	4	2024-09-23	13:08:03	Cancelada	Emergencia
133	5	4	2025-05-23	14:47:47	Cancelada	Emergencia
134	5	2	2025-05-26	13:45:10	Atendida	General
135	1	4	2025-04-17	13:18:03	Pendiente	Emergencia
136	3	2	2024-11-25	08:26:26	Cancelada	Especialista
137	1	5	2024-08-19	14:58:11	Cancelada	General
138	5	3	2025-02-22	11:57:50	Pendiente	Especialista
139	5	3	2025-07-08	13:44:09	Pendiente	Especialista
140	2	4	2025-03-09	12:08:21	Pendiente	Especialista
141	3	5	2025-06-05	11:29:06	Atendida	Emergencia
142	4	5	2025-02-04	11:19:38	Pendiente	Especialista
143	2	3	2025-07-06	14:17:58	Atendida	General
144	2	2	2025-01-07	15:33:46	Cancelada	Especialista
145	5	2	2025-04-11	15:18:01	Atendida	Emergencia
146	2	4	2024-12-03	09:37:59	Pendiente	Emergencia
147	2	1	2024-10-16	12:34:06	Cancelada	Especialista
148	5	3	2025-07-01	15:12:10	Atendida	Especialista
149	4	3	2024-12-11	08:08:20	Cancelada	General
150	1	5	2024-09-11	15:57:32	Cancelada	Especialista
151	5	1	2025-07-06	14:47:27	Cancelada	Emergencia
152	2	5	2024-08-29	14:54:14	Cancelada	General
153	3	5	2025-04-21	10:07:02	Cancelada	Emergencia
154	1	4	2025-01-29	10:24:21	Cancelada	General
155	4	1	2025-01-12	13:55:30	Atendida	Emergencia
156	1	4	2024-09-25	13:10:19	Atendida	Emergencia
157	3	2	2025-06-30	12:58:51	Pendiente	General
158	3	1	2024-12-21	11:42:57	Cancelada	Especialista
159	1	4	2024-12-23	11:54:59	Cancelada	Emergencia
160	3	5	2024-11-13	14:10:44	Pendiente	Emergencia
161	3	5	2025-06-29	14:57:18	Pendiente	Especialista
162	4	3	2025-07-23	14:53:06	Atendida	Emergencia
163	3	1	2025-06-15	12:05:33	Cancelada	General
164	5	3	2025-07-18	08:21:20	Atendida	General
165	1	2	2024-11-06	10:55:18	Cancelada	Emergencia
166	4	2	2025-04-19	12:11:56	Atendida	Especialista
167	5	3	2025-07-10	08:40:33	Cancelada	Especialista
168	4	4	2024-11-09	10:03:53	Pendiente	Especialista
169	3	4	2024-08-13	14:15:04	Pendiente	Especialista
170	3	5	2025-06-26	13:08:15	Cancelada	General
171	4	4	2024-11-28	11:15:29	Cancelada	General
172	4	2	2025-07-23	08:40:54	Atendida	Emergencia
173	5	5	2024-08-06	12:49:18	Pendiente	General
174	3	5	2025-07-13	10:00:42	Pendiente	General
175	3	2	2024-11-26	12:16:50	Pendiente	General
176	3	2	2024-08-15	08:26:14	Cancelada	General
177	4	5	2025-03-28	12:21:48	Pendiente	Emergencia
178	3	2	2024-10-14	12:46:26	Pendiente	Especialista
179	5	2	2024-10-17	12:19:25	Atendida	Especialista
180	1	3	2024-10-14	10:05:39	Pendiente	Especialista
181	4	1	2025-01-22	08:13:24	Pendiente	Emergencia
182	4	5	2024-12-11	12:49:19	Cancelada	Especialista
183	4	5	2024-09-10	15:58:33	Cancelada	Especialista
184	1	3	2025-07-13	15:52:23	Pendiente	Emergencia
185	4	2	2025-03-14	10:07:09	Atendida	Especialista
186	5	2	2024-10-10	08:29:24	Atendida	Emergencia
187	2	4	2024-11-08	14:12:54	Pendiente	General
188	3	1	2025-07-12	09:15:16	Pendiente	Especialista
189	1	3	2025-02-24	12:38:59	Cancelada	Emergencia
190	5	2	2025-05-20	15:10:28	Pendiente	General
191	1	2	2025-07-15	15:26:46	Atendida	Especialista
192	2	4	2024-10-21	10:12:09	Atendida	Especialista
193	5	2	2024-12-23	09:06:36	Atendida	General
194	1	3	2024-11-12	14:52:21	Pendiente	Especialista
195	1	4	2025-03-24	11:07:28	Atendida	General
196	1	2	2025-06-30	09:48:56	Atendida	General
197	2	4	2024-08-20	12:05:31	Atendida	Especialista
198	2	3	2024-12-21	08:15:13	Cancelada	General
199	3	1	2025-07-11	14:21:43	Pendiente	Emergencia
200	3	3	2024-09-09	13:58:09	Cancelada	General
201	3	1	2025-01-28	12:15:04	Cancelada	Emergencia
202	5	1	2025-02-03	08:10:22	Pendiente	General
203	2	5	2024-10-18	15:49:34	Cancelada	Emergencia
204	3	1	2024-12-27	14:46:06	Cancelada	Especialista
205	5	5	2025-05-14	12:35:27	Pendiente	General
206	1	3	2024-11-09	09:25:37	Atendida	General
207	3	2	2024-12-23	12:21:20	Pendiente	Especialista
208	5	2	2024-11-14	09:56:05	Pendiente	Emergencia
209	4	1	2025-04-06	11:40:38	Cancelada	General
210	1	1	2024-10-13	10:56:57	Pendiente	Emergencia
211	1	4	2024-10-01	10:49:24	Cancelada	Especialista
212	2	2	2025-03-05	13:26:16	Pendiente	Emergencia
213	3	2	2025-02-13	15:47:59	Cancelada	Emergencia
214	3	1	2024-08-04	08:33:09	Pendiente	Emergencia
215	4	5	2025-04-04	13:44:38	Pendiente	Emergencia
216	3	5	2025-02-27	08:58:00	Atendida	Especialista
217	5	2	2025-03-15	11:39:42	Cancelada	General
218	3	3	2024-12-27	09:08:19	Pendiente	General
219	5	5	2025-01-25	10:26:15	Atendida	Emergencia
220	1	3	2025-07-12	09:58:25	Cancelada	Emergencia
221	1	4	2025-05-13	15:04:10	Cancelada	Especialista
222	4	3	2025-05-12	10:58:25	Cancelada	Especialista
223	4	5	2024-12-15	12:38:24	Pendiente	Especialista
224	1	5	2025-02-23	14:42:07	Atendida	Especialista
225	5	2	2025-04-19	15:27:40	Cancelada	General
226	5	2	2024-08-07	12:22:51	Atendida	Especialista
227	1	4	2024-09-12	10:03:25	Atendida	Emergencia
228	5	4	2024-12-24	08:50:06	Cancelada	Emergencia
229	3	4	2024-12-07	14:10:54	Cancelada	General
230	4	2	2024-12-02	10:48:18	Atendida	Emergencia
231	4	2	2025-06-19	14:55:07	Atendida	Especialista
232	1	3	2024-12-04	10:05:42	Cancelada	Especialista
233	1	5	2025-03-03	11:05:45	Pendiente	Emergencia
234	1	1	2025-06-02	15:17:51	Pendiente	Especialista
235	5	3	2025-05-25	13:40:04	Pendiente	Emergencia
236	3	3	2025-07-27	15:39:24	Cancelada	Emergencia
237	2	3	2025-07-29	12:51:57	Pendiente	Especialista
238	3	5	2025-05-10	12:45:44	Pendiente	Emergencia
239	2	2	2025-02-18	14:18:37	Pendiente	Emergencia
240	1	3	2025-06-20	15:01:55	Cancelada	Emergencia
241	1	2	2025-07-07	11:56:01	Pendiente	Especialista
242	4	2	2025-07-14	08:14:02	Cancelada	Emergencia
243	3	5	2024-09-26	12:19:08	Pendiente	Emergencia
244	1	3	2024-10-03	10:30:12	Cancelada	General
245	4	3	2025-01-13	15:16:42	Cancelada	Especialista
246	2	2	2024-11-28	12:01:08	Pendiente	General
247	3	1	2025-06-24	09:33:10	Atendida	Emergencia
248	2	3	2024-11-08	14:58:26	Cancelada	Emergencia
249	2	3	2024-10-13	10:34:33	Cancelada	General
250	2	2	2025-05-28	11:58:07	Atendida	Emergencia
251	4	2	2025-01-29	13:09:25	Cancelada	Emergencia
252	3	3	2025-01-23	13:00:53	Cancelada	Emergencia
253	1	5	2024-11-10	14:44:57	Pendiente	General
254	1	1	2025-01-09	13:25:39	Pendiente	General
255	2	5	2025-05-23	11:50:36	Cancelada	General
256	1	1	2024-08-12	10:46:18	Cancelada	Especialista
257	3	4	2024-10-02	10:36:59	Pendiente	Especialista
258	5	4	2025-06-22	13:37:26	Atendida	General
259	4	4	2025-05-14	12:34:15	Pendiente	General
260	1	1	2025-05-15	13:01:38	Pendiente	Emergencia
261	3	3	2024-11-06	10:52:54	Pendiente	Especialista
262	2	1	2024-08-28	09:11:42	Cancelada	Especialista
263	1	2	2024-08-18	09:30:12	Pendiente	General
264	5	5	2025-04-21	09:26:16	Pendiente	Emergencia
265	5	4	2025-05-20	15:27:45	Cancelada	General
266	2	2	2025-06-16	09:55:57	Pendiente	Especialista
267	3	1	2025-03-24	13:53:48	Atendida	Especialista
268	3	5	2025-02-08	13:16:11	Cancelada	General
269	1	1	2024-09-05	10:37:50	Cancelada	Emergencia
270	3	1	2025-05-12	11:30:44	Cancelada	General
271	5	3	2025-03-16	13:17:49	Pendiente	General
272	5	1	2025-02-07	12:54:22	Cancelada	Emergencia
273	3	1	2025-07-07	15:06:37	Pendiente	General
274	4	3	2025-07-24	14:52:56	Pendiente	Especialista
275	5	1	2024-09-04	10:19:15	Cancelada	Emergencia
276	1	1	2025-03-08	09:11:03	Cancelada	Especialista
277	4	2	2025-05-05	12:17:43	Cancelada	Emergencia
278	1	5	2025-01-29	12:53:57	Pendiente	Emergencia
279	2	3	2025-07-14	14:07:58	Pendiente	Emergencia
280	1	4	2025-04-05	11:55:58	Pendiente	General
281	4	2	2024-08-26	14:13:50	Atendida	General
282	4	5	2025-06-02	08:25:14	Atendida	Emergencia
283	5	2	2025-04-06	13:57:15	Cancelada	General
284	3	2	2025-04-24	08:14:24	Pendiente	Especialista
285	3	1	2025-02-28	10:50:28	Atendida	Especialista
286	2	4	2025-07-08	14:05:48	Atendida	Emergencia
287	3	5	2025-06-01	09:39:09	Pendiente	Especialista
288	3	4	2024-12-02	14:48:08	Cancelada	General
289	5	5	2024-10-11	09:14:47	Atendida	General
290	4	3	2025-03-01	13:38:01	Pendiente	General
291	2	4	2025-06-25	10:03:29	Pendiente	Especialista
292	1	4	2025-01-09	11:09:41	Cancelada	Emergencia
293	2	2	2025-04-07	08:00:42	Pendiente	General
294	2	3	2024-12-08	10:30:01	Atendida	Emergencia
295	3	2	2024-09-25	08:04:45	Cancelada	Especialista
296	2	5	2025-01-23	09:07:57	Cancelada	Especialista
297	2	3	2025-06-08	10:18:10	Atendida	Especialista
298	5	4	2025-04-18	15:13:08	Pendiente	General
299	1	1	2025-05-19	12:24:54	Atendida	Emergencia
300	4	4	2025-06-14	11:54:25	Atendida	Especialista
301	4	1	2024-09-18	13:36:22	Atendida	Especialista
302	5	4	2024-12-19	09:00:24	Atendida	Emergencia
303	1	1	2025-05-01	11:18:01	Atendida	General
304	2	2	2024-11-14	15:15:28	Atendida	Especialista
305	5	1	2025-06-19	09:57:52	Atendida	General
306	5	4	2025-01-27	08:21:41	Cancelada	General
307	3	1	2025-02-25	13:00:39	Cancelada	Especialista
308	4	2	2025-05-01	12:25:41	Pendiente	Especialista
309	1	4	2025-02-28	10:17:42	Pendiente	Emergencia
310	4	2	2024-11-23	08:01:07	Pendiente	General
311	3	1	2025-02-25	13:57:07	Atendida	Especialista
312	2	4	2025-03-15	15:31:54	Pendiente	Emergencia
313	3	4	2024-12-23	14:50:13	Pendiente	Especialista
314	5	4	2024-08-26	14:38:53	Cancelada	General
315	1	5	2025-03-03	09:22:09	Cancelada	Emergencia
316	2	2	2024-10-13	11:16:10	Atendida	General
317	1	3	2025-05-27	15:01:40	Atendida	Emergencia
318	4	5	2024-08-04	13:06:25	Atendida	Especialista
319	4	1	2025-06-14	15:38:04	Cancelada	Emergencia
320	1	1	2024-09-11	11:52:04	Pendiente	Especialista
321	1	1	2025-01-03	09:53:56	Cancelada	General
322	5	2	2024-09-01	10:18:40	Atendida	General
323	2	3	2024-10-01	11:47:43	Pendiente	Emergencia
324	1	2	2025-05-04	11:32:53	Cancelada	General
325	3	1	2025-04-22	14:13:41	Cancelada	Especialista
326	2	5	2025-03-08	10:38:59	Pendiente	Especialista
327	3	2	2025-05-12	12:25:15	Atendida	Especialista
328	5	5	2025-04-25	09:50:13	Cancelada	Emergencia
329	4	5	2024-10-20	12:09:21	Pendiente	General
330	4	1	2024-12-19	08:31:59	Atendida	Especialista
331	3	3	2024-09-21	08:05:18	Atendida	Especialista
332	2	1	2025-01-29	15:01:33	Pendiente	Especialista
333	5	2	2025-05-21	10:17:47	Cancelada	Emergencia
334	1	4	2025-04-10	12:17:18	Cancelada	Especialista
335	5	4	2024-11-25	10:03:36	Atendida	Emergencia
336	5	4	2025-03-01	10:52:35	Pendiente	General
337	1	1	2024-08-13	14:08:43	Cancelada	General
338	5	5	2025-01-11	14:47:45	Cancelada	Emergencia
339	5	5	2024-10-12	11:04:05	Atendida	Emergencia
340	4	1	2025-03-17	08:08:48	Pendiente	Emergencia
341	4	2	2024-12-24	12:10:20	Pendiente	General
342	4	5	2024-09-03	09:23:49	Atendida	General
343	3	3	2025-07-20	12:49:18	Pendiente	Emergencia
344	1	5	2024-09-02	12:12:41	Pendiente	General
345	2	1	2024-10-08	11:07:18	Pendiente	Especialista
346	3	3	2025-02-23	11:36:00	Pendiente	Especialista
347	5	3	2024-09-22	15:41:53	Cancelada	General
348	2	5	2025-05-28	12:13:29	Atendida	Emergencia
349	5	3	2025-05-16	11:10:33	Atendida	Especialista
350	3	1	2025-01-07	14:37:28	Atendida	Emergencia
351	4	5	2025-07-29	15:06:38	Atendida	Especialista
352	1	2	2025-02-19	11:25:09	Pendiente	Especialista
353	2	1	2025-02-06	12:59:03	Atendida	Especialista
354	1	1	2025-01-20	08:42:19	Atendida	Especialista
355	2	1	2024-11-08	13:45:29	Atendida	Emergencia
356	4	3	2024-09-03	13:10:13	Pendiente	Emergencia
357	3	4	2025-06-22	10:39:46	Pendiente	Especialista
358	3	4	2025-04-27	09:52:00	Pendiente	Emergencia
359	3	2	2025-05-24	11:34:52	Atendida	Especialista
360	1	4	2025-06-09	11:19:36	Cancelada	Especialista
361	3	2	2025-04-06	11:28:36	Atendida	General
362	5	3	2025-06-12	10:53:08	Cancelada	General
363	4	2	2024-11-15	11:42:57	Cancelada	Emergencia
364	2	3	2025-07-30	08:50:01	Atendida	Especialista
365	5	4	2024-11-08	10:10:24	Atendida	Especialista
366	4	2	2025-05-26	12:47:07	Cancelada	Emergencia
367	2	2	2025-02-26	13:46:51	Pendiente	Emergencia
368	5	5	2025-01-04	08:10:36	Atendida	Emergencia
369	4	1	2025-05-06	11:46:35	Pendiente	Especialista
370	5	3	2024-08-23	14:06:46	Pendiente	Emergencia
371	1	2	2025-02-18	13:21:52	Pendiente	General
372	1	2	2025-03-01	13:28:48	Cancelada	Emergencia
373	3	3	2025-03-11	14:18:19	Cancelada	General
374	2	1	2025-02-02	09:24:56	Cancelada	Especialista
375	3	2	2025-01-09	13:42:30	Pendiente	General
376	4	5	2024-10-27	13:40:21	Cancelada	Especialista
377	4	5	2024-08-15	12:43:11	Cancelada	Especialista
378	1	1	2025-01-25	09:14:05	Cancelada	Especialista
379	2	2	2025-01-09	08:06:59	Atendida	General
380	1	3	2025-01-26	13:29:27	Pendiente	General
381	4	3	2025-06-06	09:16:06	Atendida	General
382	5	5	2025-03-30	15:34:09	Cancelada	General
383	1	4	2024-08-30	12:11:56	Pendiente	Especialista
384	4	3	2025-01-21	14:37:42	Pendiente	Emergencia
385	4	4	2025-06-27	15:47:23	Pendiente	Especialista
386	1	3	2025-03-01	11:24:02	Atendida	General
387	1	5	2025-05-09	13:03:52	Pendiente	Emergencia
388	3	3	2025-04-05	10:05:14	Cancelada	Emergencia
389	4	5	2024-11-03	11:20:35	Cancelada	Emergencia
390	2	3	2025-05-01	11:42:52	Pendiente	General
391	4	2	2025-06-11	15:06:15	Pendiente	Emergencia
392	2	1	2025-01-03	12:59:02	Pendiente	Especialista
393	5	5	2024-10-17	14:07:31	Pendiente	Emergencia
394	4	5	2025-07-16	13:49:18	Pendiente	Especialista
395	5	4	2025-03-30	08:36:40	Atendida	Especialista
396	2	4	2024-11-05	14:53:35	Atendida	Especialista
397	5	3	2025-03-02	14:28:44	Pendiente	General
398	4	1	2024-09-09	09:18:58	Atendida	Especialista
399	5	2	2025-03-28	14:46:52	Pendiente	Especialista
400	1	5	2025-07-06	15:29:34	Cancelada	Especialista
401	1	1	2024-09-03	12:47:57	Pendiente	Emergencia
402	3	2	2025-05-05	11:10:49	Atendida	Especialista
403	1	5	2025-05-19	14:00:29	Cancelada	Emergencia
404	1	3	2024-12-24	10:50:28	Cancelada	Especialista
405	4	4	2025-06-02	13:01:31	Atendida	Emergencia
406	3	4	2025-05-12	14:14:32	Cancelada	General
407	5	3	2025-01-07	12:48:44	Pendiente	Especialista
408	5	3	2024-09-03	13:25:27	Cancelada	Emergencia
409	2	5	2024-09-26	09:54:59	Cancelada	Especialista
410	1	3	2025-05-09	14:39:09	Atendida	Especialista
411	4	2	2025-02-17	09:22:28	Pendiente	Especialista
412	4	1	2025-01-10	08:02:11	Pendiente	General
413	2	2	2025-04-14	13:50:37	Atendida	Emergencia
414	1	2	2024-11-05	12:37:03	Atendida	Especialista
415	2	4	2025-01-19	14:35:02	Cancelada	Emergencia
416	3	3	2024-12-19	15:38:14	Pendiente	General
417	2	5	2025-05-22	09:15:24	Cancelada	Emergencia
418	2	1	2025-05-13	10:23:04	Pendiente	Emergencia
419	3	3	2025-03-20	11:16:48	Pendiente	General
420	1	3	2024-11-04	10:52:11	Atendida	General
421	5	2	2025-07-04	12:42:31	Cancelada	General
422	1	4	2025-03-12	14:10:43	Pendiente	General
423	4	5	2025-02-15	15:44:59	Cancelada	General
424	3	3	2024-12-27	13:06:11	Atendida	General
425	5	5	2024-09-18	10:44:40	Atendida	General
426	1	4	2024-08-27	10:56:52	Pendiente	Emergencia
427	4	5	2025-06-20	08:25:58	Atendida	General
428	5	1	2025-04-21	08:20:05	Cancelada	Especialista
429	5	5	2025-07-20	09:41:42	Cancelada	General
430	5	4	2024-12-02	09:24:44	Atendida	General
431	4	5	2025-06-07	14:53:51	Cancelada	Especialista
432	4	4	2024-11-13	10:37:53	Atendida	Emergencia
433	3	5	2025-07-28	12:26:11	Pendiente	General
434	4	2	2025-03-05	08:47:46	Cancelada	Especialista
435	2	1	2025-05-13	13:32:37	Atendida	Emergencia
436	2	2	2025-01-22	09:29:43	Atendida	Emergencia
437	3	3	2025-04-16	10:21:08	Atendida	Emergencia
438	2	4	2025-03-12	10:44:20	Cancelada	Emergencia
439	3	3	2025-04-07	08:28:57	Atendida	General
440	2	1	2025-06-10	08:14:03	Cancelada	General
441	3	4	2025-03-13	15:47:58	Pendiente	Especialista
442	5	5	2025-07-22	10:23:15	Atendida	Especialista
443	2	4	2024-12-26	09:07:53	Pendiente	General
444	5	5	2025-04-30	08:21:41	Atendida	Emergencia
445	1	3	2024-10-09	13:18:42	Pendiente	General
446	5	4	2025-01-08	14:55:15	Cancelada	Especialista
447	5	4	2025-05-08	13:40:24	Atendida	Especialista
448	3	3	2025-06-01	08:16:56	Pendiente	General
449	5	4	2025-02-02	14:31:26	Atendida	Emergencia
450	5	1	2024-09-29	11:19:21	Pendiente	General
451	1	3	2024-10-29	09:41:26	Pendiente	General
452	5	2	2025-01-20	11:08:43	Atendida	General
453	2	4	2025-02-24	10:13:47	Pendiente	Especialista
454	1	4	2025-04-28	15:08:05	Cancelada	Especialista
455	2	1	2024-09-01	13:50:28	Pendiente	General
456	2	4	2025-03-03	09:55:52	Pendiente	Especialista
457	3	3	2025-07-29	13:50:20	Cancelada	Emergencia
458	2	5	2025-07-19	11:00:53	Atendida	General
459	1	5	2025-06-05	15:14:29	Atendida	Emergencia
460	4	4	2024-09-11	09:02:37	Cancelada	General
461	5	4	2025-05-05	12:10:28	Pendiente	Especialista
462	4	4	2025-03-16	13:11:17	Cancelada	Especialista
463	5	4	2025-07-11	15:09:14	Cancelada	General
464	2	2	2025-02-07	14:38:43	Pendiente	General
465	3	3	2024-11-08	08:29:01	Pendiente	Especialista
466	3	5	2024-11-28	15:11:09	Cancelada	Emergencia
467	5	3	2025-01-30	08:24:34	Atendida	Emergencia
468	1	5	2025-06-28	09:30:20	Pendiente	Especialista
469	3	2	2024-08-19	13:14:22	Atendida	General
470	5	3	2025-01-16	13:43:54	Cancelada	Especialista
471	1	1	2024-11-22	13:21:10	Cancelada	General
472	2	4	2025-04-17	12:53:58	Atendida	Especialista
473	2	2	2025-01-04	12:40:45	Atendida	Especialista
474	3	4	2025-01-26	14:14:35	Atendida	Especialista
475	4	1	2025-04-04	08:48:46	Atendida	Emergencia
476	5	2	2025-01-13	15:08:01	Cancelada	Emergencia
477	5	3	2024-10-25	10:57:21	Cancelada	Especialista
478	4	4	2025-05-06	15:12:05	Cancelada	Emergencia
479	2	1	2025-01-01	15:56:49	Cancelada	Emergencia
480	2	4	2025-06-23	10:00:17	Cancelada	General
481	2	1	2025-03-14	13:30:33	Atendida	Especialista
482	3	4	2024-08-28	09:07:38	Pendiente	General
483	1	5	2025-04-26	08:04:57	Cancelada	Especialista
484	3	5	2025-02-19	13:00:25	Atendida	Emergencia
485	1	5	2024-12-15	13:02:20	Cancelada	General
486	4	2	2025-07-06	14:47:45	Cancelada	Especialista
487	4	4	2025-07-26	11:59:33	Pendiente	General
488	4	1	2024-08-29	09:18:20	Atendida	Especialista
489	5	1	2024-12-09	10:56:46	Pendiente	Emergencia
490	2	3	2025-03-28	13:56:56	Pendiente	General
491	5	5	2025-06-26	11:00:15	Pendiente	General
492	2	3	2024-08-11	11:12:38	Cancelada	Especialista
493	1	1	2025-04-16	09:40:56	Pendiente	Especialista
494	1	2	2025-04-12	13:40:48	Atendida	Emergencia
495	3	3	2024-08-07	15:07:46	Cancelada	General
496	3	5	2024-08-26	11:34:10	Atendida	Emergencia
497	3	5	2025-07-18	12:06:29	Atendida	General
498	2	1	2024-08-17	10:41:19	Cancelada	Especialista
499	2	4	2025-01-08	13:24:27	Atendida	Emergencia
500	3	2	2025-03-17	12:31:28	Atendida	Emergencia
501	3	1	2025-01-06	10:12:31	Cancelada	General
502	5	1	2024-08-19	13:44:07	Atendida	Especialista
503	5	2	2025-07-22	15:59:29	Atendida	Emergencia
504	5	2	2025-01-06	09:27:08	Cancelada	Emergencia
505	3	1	2025-06-16	13:48:47	Cancelada	Emergencia
506	1	2	2025-08-01	12:00:00	Pendiente	General
\.


--
-- Data for Name: detalle_receta; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.detalle_receta (id_detalle, id_receta, id_medicamento, dosis, frecuencia, duracion_dias) FROM stdin;
1	1	1	1 tableta	Cada 8 horas	5
2	1	4	1 cápsula	Cada 12 horas	7
3	2	5	1 tableta	Cada 24 horas	10
5	3	1	1 tableta	Cada 8 horas	4
\.


--
-- Data for Name: especialidades; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.especialidades (id_especialidad, nombre_especialidad) FROM stdin;
1	Pediatría
2	Cardiología
3	Dermatología
4	Neurología
5	Medicina General
\.


--
-- Data for Name: facturas; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.facturas (id_factura, id_cita, fecha_emision, total, tipo_consulta) FROM stdin;
1	3	2025-07-18	20.00	General
2	5	2025-07-19	50.00	Emergencia
3	1	2025-08-01	20.00	General
\.


--
-- Data for Name: log_acciones; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.log_acciones (id, usuario, rol_actual, ip_origen, terminal, fecha, accion, tabla_afectada, id_afectado, transaccion, hash_anterior) FROM stdin;
1	postgres	postgres	192.168.65.1/32	localhost	2025-08-01 14:42:19.784441	UPDATE	tratamientos	\N	\N	56e9eca3b8f8312a3b8c991e728d16d7e6fc04375bb035ab545ca62b6ac85f6b
2	postgres	postgres	192.168.65.1/32	localhost	2025-08-01 14:52:59.156033	INSERT	facturas	\N	\N	\N
3	postgres	postgres	172.18.0.1/32	localhost	2025-08-02 13:11:10.12894	INSERT	pacientes	\N	\N	\N
\.


--
-- Data for Name: log_intentos; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.log_intentos (id, usuario, fecha, ip_origen, mensaje) FROM stdin;
1	usuario_falso	2025-08-01 12:24:32.871957	192.168.0.105	Intento fallido de acceso
\.


--
-- Data for Name: log_usuarios; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.log_usuarios (id_log, id_usuario, accion, nombre_usuario, fecha) FROM stdin;
1	8	INSERT	recepcionista_0	2025-08-02 09:11:04.62667
2	9	INSERT	recepcion_1	2025-08-02 12:56:00.756226
\.


--
-- Data for Name: medicamentos; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.medicamentos (id_medicamento, nombre, descripcion, stock_actual) FROM stdin;
2	Amoxicilina 500mg	Antibiótico de amplio espectro	100
3	Ibuprofeno 400mg	Analgésico, antiinflamatorio	150
4	Omeprazol 20mg	Protector gástrico	80
5	Loratadina 10mg	Antihistamínico	120
1	Paracetamol 500mg	Analgésico y antipirético	199
\.


--
-- Data for Name: medicos; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.medicos (id_medico, nombres, apellidos, especialidad_id, telefono, email) FROM stdin;
1	Ana	Martínez	1	0991234567	ana.martinez@hospital.com
2	Carlos	Vera	2	0987654321	carlos.vera@hospital.com
3	Luis	Gómez	3	0976543210	luis.gomez@hospital.com
4	María	Paredes	4	0961237890	maria.paredes@hospital.com
5	Jorge	Ramírez	5	0954567890	jorge.ramirez@hospital.com
\.


--
-- Data for Name: notificaciones; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.notificaciones (id_notificacion, id_cita, mensaje, fecha) FROM stdin;
1	9	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
2	10	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
3	17	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
4	18	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
5	19	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
6	20	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
7	25	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
8	26	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
9	28	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
10	30	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
11	31	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
12	32	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
13	34	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
14	37	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
15	38	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
16	39	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
17	41	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
18	44	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
19	48	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
20	51	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
21	52	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
22	54	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
23	63	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
24	67	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
25	69	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
26	70	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
27	71	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
28	74	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
29	75	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
30	76	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
31	77	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
32	78	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
33	79	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
34	80	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
35	81	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
36	83	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
37	84	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
38	85	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
39	88	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
40	89	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
41	90	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
42	94	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
43	96	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
44	98	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
45	99	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
46	102	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
47	103	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
48	108	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
49	109	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
50	112	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
51	118	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
52	120	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
53	121	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
54	123	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
55	124	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
56	125	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
57	130	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
58	135	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
59	138	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
60	139	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
61	140	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
62	142	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
63	146	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
64	157	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
65	160	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
66	161	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
67	168	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
68	169	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
69	173	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
70	174	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
71	175	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
72	177	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
73	178	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
74	180	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
75	181	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
76	184	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
77	187	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
78	188	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
79	190	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
80	194	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
81	199	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
82	202	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
83	205	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
84	207	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
85	208	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
86	210	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
87	212	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
88	214	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
89	215	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
90	218	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
91	223	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
92	233	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
93	234	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
94	235	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
95	237	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
96	238	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
97	239	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
98	241	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
99	243	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
100	246	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
101	253	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
102	254	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
103	257	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
104	259	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
105	260	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
106	261	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
107	263	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
108	264	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
109	266	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
110	271	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
111	273	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
112	274	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
113	278	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
114	279	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
115	280	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
116	284	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
117	287	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
118	290	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
119	291	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
120	293	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
121	298	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
122	308	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
123	309	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
124	310	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
125	312	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
126	313	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
127	320	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
128	323	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
129	326	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
130	329	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
131	332	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
132	336	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
133	340	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
134	341	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
135	343	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
136	344	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
137	345	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
138	346	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
139	352	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
140	356	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
141	357	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
142	358	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
143	367	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
144	369	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
145	370	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
146	371	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
147	375	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
148	380	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
149	383	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
150	384	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
151	385	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
152	387	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
153	390	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
154	391	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
155	392	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
156	393	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
157	394	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
158	397	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
159	399	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
160	401	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
161	407	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
162	411	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
163	412	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
164	416	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
165	418	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
166	419	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
167	422	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
168	426	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
169	433	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
170	441	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
171	443	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
172	445	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
173	448	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
174	450	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
175	451	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
176	453	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
177	455	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
178	456	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
179	461	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
180	464	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
181	465	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
182	468	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
183	482	Se ha agendado una nueva cita para el paciente Esteban Rojas	2025-08-01 12:23:29.293599
184	487	Se ha agendado una nueva cita para el paciente Valentina Silva	2025-08-01 12:23:29.293599
185	489	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
186	490	Se ha agendado una nueva cita para el paciente Mateo Cueva	2025-08-01 12:23:29.293599
187	491	Se ha agendado una nueva cita para el paciente Fernanda León	2025-08-01 12:23:29.293599
188	493	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 12:23:29.293599
189	506	Se ha agendado una nueva cita para el paciente Lucía Herrera	2025-08-01 14:27:27.826515
\.


--
-- Data for Name: pacientes; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.pacientes (id_paciente, nombres, apellidos, fecha_nacimiento, genero, direccion, telefono, email, contacto_emergencia_nombre, contacto_emergencia_telefono, historia_clinica, fecha_creacion) FROM stdin;
1	Lucía	Herrera	1995-04-10	F	Calle A #123	0981122334	lucia.herrera@gmail.com	Pedro Herrera	0984455667	Asma desde la infancia.	2025-08-02 12:35:36.469674
2	Mateo	Cueva	2001-01-25	M	Av. Central 45	0999988776	mateo.cueva@gmail.com	Ana Cueva	0991239876	Historial de migrañas.	2025-08-02 12:35:36.469674
3	Esteban	Rojas	1980-11-15	M	Calle Sur 12	0977744112	esteban.rojas@gmail.com	Luis Rojas	0968877665	Hipertensión leve.	2025-08-02 12:35:36.469674
4	Valentina	Silva	2005-07-02	F	Barrio Norte 77	0955544332	valen.silva@gmail.com	Rosa Silva	0958887776	Sin historial clínico.	2025-08-02 12:35:36.469674
5	Fernanda	León	1990-09-10	F	Av. del Sol 88	0967890123	fernanda.leon@gmail.com	Carlos León	0992224443	Alergia a penicilina.	2025-08-02 12:35:36.469674
6	Juan	Herrera	1995-04-10	M	Calle A #123	0981122334	\\xc30d040703022e2db22aebe2a3897ad24601e2527fa3ca031c45de6669d485a95fa126ebd9e2222ea59c5c72213cb287c90ffa4e2fa866e3303c511f3522bcb5fc25d9f13cb23589fec52b29a46bb90fc3d1eaad024693	Pedro Herrera	0984455667	Asma desde la infancia.	2025-08-02 13:11:10.12894
\.


--
-- Data for Name: recetas; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.recetas (id_receta, id_cita, fecha, observaciones, entregada) FROM stdin;
1	3	2025-07-18	Tratamiento para dolor muscular.	t
2	5	2025-07-19	Control de síntomas alérgicos.	f
3	6	2025-07-10	Tratamiento para el dolor de cabeza.	t
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.roles (id_rol, nombre_rol) FROM stdin;
1	Recepcionista
2	Doctor
3	Farmacia
4	Auditor
\.


--
-- Data for Name: tarifas; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.tarifas (tipo_consulta, costo) FROM stdin;
General	20.00
Especialista	35.00
Emergencia	50.00
\.


--
-- Data for Name: tratamientos; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.tratamientos (id_tratamiento, id_paciente, descripcion, fecha_inicio, fecha_fin, estado) FROM stdin;
2	3	Control de presión arterial	2025-06-01	2025-07-15	Finalizado
3	2	Terapia para migraña crónica	2025-07-10	2025-08-10	Activo
1	1	Tratamiento respiratorio para asma	2025-07-01	2025-07-31	Finalizado
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: hospital; Owner: postgres
--

COPY hospital.usuarios (id_usuario, nombre_usuario, clave, rol_id) FROM stdin;
1	recepcion1	123456	1
2	doctor_cvera	medico123	2
3	farmacia1	farm@2025	3
4	auditor_admin	audit2025	4
5	doctor_aparedes	neurologia123	2
6	admin_general	admin1234	4
8	recepcionista_0	rcp123	1
9	recepcion_1	\\x5ac0852e770506dcd80f1a36d20ba7878bf82244b836d9324593bd14bc56dcb5	1
\.


--
-- Data for Name: log_acciones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.log_acciones (id, usuario, rol_actual, ip_origen, terminal, fecha, accion, tabla_afectada, id_afectado, transaccion, hash_anterior) FROM stdin;
\.


--
-- Name: citas_medicas_id_cita_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.citas_medicas_id_cita_seq', 506, true);


--
-- Name: detalle_receta_id_detalle_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.detalle_receta_id_detalle_seq', 5, true);


--
-- Name: especialidades_id_especialidad_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.especialidades_id_especialidad_seq', 5, true);


--
-- Name: facturas_id_factura_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.facturas_id_factura_seq', 3, true);


--
-- Name: log_acciones_id_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.log_acciones_id_seq', 3, true);


--
-- Name: log_intentos_id_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.log_intentos_id_seq', 1, true);


--
-- Name: log_usuarios_id_log_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.log_usuarios_id_log_seq', 2, true);


--
-- Name: medicamentos_id_medicamento_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.medicamentos_id_medicamento_seq', 5, true);


--
-- Name: medicos_id_medico_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.medicos_id_medico_seq', 5, true);


--
-- Name: notificaciones_id_notificacion_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.notificaciones_id_notificacion_seq', 189, true);


--
-- Name: pacientes_id_paciente_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.pacientes_id_paciente_seq', 6, true);


--
-- Name: recetas_id_receta_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.recetas_id_receta_seq', 3, true);


--
-- Name: roles_id_rol_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.roles_id_rol_seq', 4, true);


--
-- Name: tratamientos_id_tratamiento_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.tratamientos_id_tratamiento_seq', 3, true);


--
-- Name: usuarios_id_usuario_seq; Type: SEQUENCE SET; Schema: hospital; Owner: postgres
--

SELECT pg_catalog.setval('hospital.usuarios_id_usuario_seq', 9, true);


--
-- Name: log_acciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.log_acciones_id_seq', 1, false);


--
-- Name: citas_medicas citas_medicas_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.citas_medicas
    ADD CONSTRAINT citas_medicas_pkey PRIMARY KEY (id_cita);


--
-- Name: detalle_receta detalle_receta_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.detalle_receta
    ADD CONSTRAINT detalle_receta_pkey PRIMARY KEY (id_detalle);


--
-- Name: especialidades especialidades_nombre_especialidad_key; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.especialidades
    ADD CONSTRAINT especialidades_nombre_especialidad_key UNIQUE (nombre_especialidad);


--
-- Name: especialidades especialidades_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.especialidades
    ADD CONSTRAINT especialidades_pkey PRIMARY KEY (id_especialidad);


--
-- Name: facturas facturas_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.facturas
    ADD CONSTRAINT facturas_pkey PRIMARY KEY (id_factura);


--
-- Name: log_acciones log_acciones_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.log_acciones
    ADD CONSTRAINT log_acciones_pkey PRIMARY KEY (id);


--
-- Name: log_intentos log_intentos_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.log_intentos
    ADD CONSTRAINT log_intentos_pkey PRIMARY KEY (id);


--
-- Name: log_usuarios log_usuarios_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.log_usuarios
    ADD CONSTRAINT log_usuarios_pkey PRIMARY KEY (id_log);


--
-- Name: medicamentos medicamentos_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.medicamentos
    ADD CONSTRAINT medicamentos_pkey PRIMARY KEY (id_medicamento);


--
-- Name: medicos medicos_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.medicos
    ADD CONSTRAINT medicos_pkey PRIMARY KEY (id_medico);


--
-- Name: notificaciones notificaciones_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.notificaciones
    ADD CONSTRAINT notificaciones_pkey PRIMARY KEY (id_notificacion);


--
-- Name: pacientes pacientes_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.pacientes
    ADD CONSTRAINT pacientes_pkey PRIMARY KEY (id_paciente);


--
-- Name: recetas recetas_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.recetas
    ADD CONSTRAINT recetas_pkey PRIMARY KEY (id_receta);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id_rol);


--
-- Name: tarifas tarifas_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.tarifas
    ADD CONSTRAINT tarifas_pkey PRIMARY KEY (tipo_consulta);


--
-- Name: tratamientos tratamientos_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.tratamientos
    ADD CONSTRAINT tratamientos_pkey PRIMARY KEY (id_tratamiento);


--
-- Name: usuarios usuarios_nombre_usuario_key; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.usuarios
    ADD CONSTRAINT usuarios_nombre_usuario_key UNIQUE (nombre_usuario);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id_usuario);


--
-- Name: log_acciones log_acciones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.log_acciones
    ADD CONSTRAINT log_acciones_pkey PRIMARY KEY (id);


--
-- Name: idx_citas_estado; Type: INDEX; Schema: hospital; Owner: postgres
--

CREATE INDEX idx_citas_estado ON hospital.citas_medicas USING btree (estado);


--
-- Name: idx_citas_fecha; Type: INDEX; Schema: hospital; Owner: postgres
--

CREATE INDEX idx_citas_fecha ON hospital.citas_medicas USING btree (fecha);


--
-- Name: idx_citas_medico; Type: INDEX; Schema: hospital; Owner: postgres
--

CREATE INDEX idx_citas_medico ON hospital.citas_medicas USING btree (id_medico);


--
-- Name: idx_citas_medico_fecha; Type: INDEX; Schema: hospital; Owner: postgres
--

CREATE INDEX idx_citas_medico_fecha ON hospital.citas_medicas USING btree (id_medico, fecha);


--
-- Name: idx_citas_paciente; Type: INDEX; Schema: hospital; Owner: postgres
--

CREATE INDEX idx_citas_paciente ON hospital.citas_medicas USING btree (id_paciente);


--
-- Name: idx_citas_tipo_estado; Type: INDEX; Schema: hospital; Owner: postgres
--

CREATE INDEX idx_citas_tipo_estado ON hospital.citas_medicas USING btree (tipo_consulta, estado);


--
-- Name: idx_detalle_medicamento; Type: INDEX; Schema: hospital; Owner: postgres
--

CREATE INDEX idx_detalle_medicamento ON hospital.detalle_receta USING btree (id_medicamento);


--
-- Name: idx_paciente_genero; Type: INDEX; Schema: hospital; Owner: postgres
--

CREATE INDEX idx_paciente_genero ON hospital.pacientes USING btree (genero);


--
-- Name: idx_pacientes_nombre; Type: INDEX; Schema: hospital; Owner: postgres
--

CREATE INDEX idx_pacientes_nombre ON hospital.pacientes USING btree (nombres);


--
-- Name: idx_recetas_cita; Type: INDEX; Schema: hospital; Owner: postgres
--

CREATE INDEX idx_recetas_cita ON hospital.recetas USING btree (id_cita);


--
-- Name: idx_tratamientos_estado; Type: INDEX; Schema: hospital; Owner: postgres
--

CREATE INDEX idx_tratamientos_estado ON hospital.tratamientos USING btree (estado);


--
-- Name: idx_tratamientos_paciente_estado; Type: INDEX; Schema: hospital; Owner: postgres
--

CREATE INDEX idx_tratamientos_paciente_estado ON hospital.tratamientos USING btree (id_paciente, estado);


--
-- Name: detalle_receta tr_descontar_stock; Type: TRIGGER; Schema: hospital; Owner: postgres
--

CREATE TRIGGER tr_descontar_stock AFTER INSERT ON hospital.detalle_receta FOR EACH ROW EXECUTE FUNCTION hospital.descontar_stock_medicamento();


--
-- Name: usuarios tr_log_usuarios; Type: TRIGGER; Schema: hospital; Owner: postgres
--

CREATE TRIGGER tr_log_usuarios AFTER INSERT OR DELETE OR UPDATE ON hospital.usuarios FOR EACH ROW EXECUTE FUNCTION hospital.log_cambios_usuarios();


--
-- Name: citas_medicas tr_notificacion_cita; Type: TRIGGER; Schema: hospital; Owner: postgres
--

CREATE TRIGGER tr_notificacion_cita AFTER INSERT ON hospital.citas_medicas FOR EACH ROW EXECUTE FUNCTION hospital.notificar_cita_paciente();


--
-- Name: facturas trg_audit_facturas_delete; Type: TRIGGER; Schema: hospital; Owner: postgres
--

CREATE TRIGGER trg_audit_facturas_delete AFTER DELETE ON hospital.facturas FOR EACH ROW EXECUTE FUNCTION hospital.fn_log_accion();


--
-- Name: facturas trg_audit_facturas_insert; Type: TRIGGER; Schema: hospital; Owner: postgres
--

CREATE TRIGGER trg_audit_facturas_insert AFTER INSERT ON hospital.facturas FOR EACH ROW EXECUTE FUNCTION hospital.fn_log_accion();


--
-- Name: facturas trg_audit_facturas_update; Type: TRIGGER; Schema: hospital; Owner: postgres
--

CREATE TRIGGER trg_audit_facturas_update AFTER UPDATE ON hospital.facturas FOR EACH ROW EXECUTE FUNCTION hospital.fn_log_accion();


--
-- Name: pacientes trg_audit_pacientes_delete; Type: TRIGGER; Schema: hospital; Owner: postgres
--

CREATE TRIGGER trg_audit_pacientes_delete AFTER DELETE ON hospital.pacientes FOR EACH ROW EXECUTE FUNCTION hospital.fn_log_accion();


--
-- Name: pacientes trg_audit_pacientes_insert; Type: TRIGGER; Schema: hospital; Owner: postgres
--

CREATE TRIGGER trg_audit_pacientes_insert AFTER INSERT ON hospital.pacientes FOR EACH ROW EXECUTE FUNCTION hospital.fn_log_accion();


--
-- Name: pacientes trg_audit_pacientes_update; Type: TRIGGER; Schema: hospital; Owner: postgres
--

CREATE TRIGGER trg_audit_pacientes_update AFTER UPDATE ON hospital.pacientes FOR EACH ROW EXECUTE FUNCTION hospital.fn_log_accion();


--
-- Name: tratamientos trg_audit_tratamientos_delete; Type: TRIGGER; Schema: hospital; Owner: postgres
--

CREATE TRIGGER trg_audit_tratamientos_delete AFTER DELETE ON hospital.tratamientos FOR EACH ROW EXECUTE FUNCTION hospital.fn_log_accion();


--
-- Name: tratamientos trg_audit_tratamientos_insert; Type: TRIGGER; Schema: hospital; Owner: postgres
--

CREATE TRIGGER trg_audit_tratamientos_insert AFTER INSERT ON hospital.tratamientos FOR EACH ROW EXECUTE FUNCTION hospital.fn_log_accion();


--
-- Name: tratamientos trg_audit_tratamientos_update; Type: TRIGGER; Schema: hospital; Owner: postgres
--

CREATE TRIGGER trg_audit_tratamientos_update AFTER UPDATE ON hospital.tratamientos FOR EACH ROW EXECUTE FUNCTION hospital.fn_log_accion();


--
-- Name: citas_medicas citas_medicas_id_medico_fkey; Type: FK CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.citas_medicas
    ADD CONSTRAINT citas_medicas_id_medico_fkey FOREIGN KEY (id_medico) REFERENCES hospital.medicos(id_medico);


--
-- Name: citas_medicas citas_medicas_id_paciente_fkey; Type: FK CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.citas_medicas
    ADD CONSTRAINT citas_medicas_id_paciente_fkey FOREIGN KEY (id_paciente) REFERENCES hospital.pacientes(id_paciente);


--
-- Name: detalle_receta detalle_receta_id_medicamento_fkey; Type: FK CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.detalle_receta
    ADD CONSTRAINT detalle_receta_id_medicamento_fkey FOREIGN KEY (id_medicamento) REFERENCES hospital.medicamentos(id_medicamento);


--
-- Name: detalle_receta detalle_receta_id_receta_fkey; Type: FK CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.detalle_receta
    ADD CONSTRAINT detalle_receta_id_receta_fkey FOREIGN KEY (id_receta) REFERENCES hospital.recetas(id_receta);


--
-- Name: facturas facturas_id_cita_fkey; Type: FK CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.facturas
    ADD CONSTRAINT facturas_id_cita_fkey FOREIGN KEY (id_cita) REFERENCES hospital.citas_medicas(id_cita);


--
-- Name: medicos medicos_especialidad_id_fkey; Type: FK CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.medicos
    ADD CONSTRAINT medicos_especialidad_id_fkey FOREIGN KEY (especialidad_id) REFERENCES hospital.especialidades(id_especialidad);


--
-- Name: recetas recetas_id_cita_fkey; Type: FK CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.recetas
    ADD CONSTRAINT recetas_id_cita_fkey FOREIGN KEY (id_cita) REFERENCES hospital.citas_medicas(id_cita);


--
-- Name: tratamientos tratamientos_id_paciente_fkey; Type: FK CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.tratamientos
    ADD CONSTRAINT tratamientos_id_paciente_fkey FOREIGN KEY (id_paciente) REFERENCES hospital.pacientes(id_paciente);


--
-- Name: usuarios usuarios_rol_id_fkey; Type: FK CONSTRAINT; Schema: hospital; Owner: postgres
--

ALTER TABLE ONLY hospital.usuarios
    ADD CONSTRAINT usuarios_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES hospital.roles(id_rol);


--
-- Name: TABLE pacientes; Type: ACL; Schema: hospital; Owner: postgres
--

GRANT SELECT ON TABLE hospital.pacientes TO cliente;
GRANT SELECT ON TABLE hospital.pacientes TO auditor;


--
-- Name: TABLE tratamientos; Type: ACL; Schema: hospital; Owner: postgres
--

GRANT SELECT ON TABLE hospital.tratamientos TO cliente;
GRANT SELECT,INSERT,UPDATE ON TABLE hospital.tratamientos TO medico;


--
-- Name: TABLE vista_resumen_citas; Type: ACL; Schema: hospital; Owner: postgres
--

GRANT SELECT ON TABLE hospital.vista_resumen_citas TO recepcionista;


--
-- PostgreSQL database dump complete
--

